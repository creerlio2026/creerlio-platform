module.exports=[25532,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_ai-assistant_page_actions_a70f9da5.js.map