module.exports=[82757,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_profile_page_actions_ea523a99.js.map