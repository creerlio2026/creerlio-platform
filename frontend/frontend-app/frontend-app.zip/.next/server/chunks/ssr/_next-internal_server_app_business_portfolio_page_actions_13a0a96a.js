module.exports=[46850,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_business_portfolio_page_actions_13a0a96a.js.map