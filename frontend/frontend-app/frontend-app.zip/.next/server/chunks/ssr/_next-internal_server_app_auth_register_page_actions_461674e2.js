module.exports=[7977,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_register_page_actions_461674e2.js.map