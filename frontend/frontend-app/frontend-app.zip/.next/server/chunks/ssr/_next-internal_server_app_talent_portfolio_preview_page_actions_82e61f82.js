module.exports=[67173,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_portfolio_preview_page_actions_82e61f82.js.map