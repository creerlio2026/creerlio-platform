module.exports=[77648,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_portfolio_page_actions_d20cea07.js.map