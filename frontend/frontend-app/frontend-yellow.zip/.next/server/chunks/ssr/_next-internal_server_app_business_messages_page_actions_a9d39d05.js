module.exports=[52581,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_business_messages_page_actions_a9d39d05.js.map