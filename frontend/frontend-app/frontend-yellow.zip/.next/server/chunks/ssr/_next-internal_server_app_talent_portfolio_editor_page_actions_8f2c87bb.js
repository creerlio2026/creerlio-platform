module.exports=[87201,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_portfolio_editor_page_actions_8f2c87bb.js.map