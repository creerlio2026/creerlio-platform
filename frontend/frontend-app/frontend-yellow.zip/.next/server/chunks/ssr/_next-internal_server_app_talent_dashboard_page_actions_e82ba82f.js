module.exports=[66890,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_dashboard_page_actions_e82ba82f.js.map