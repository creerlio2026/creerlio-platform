module.exports=[9988,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_talent_jobs_page_actions_1d101c4a.js.map